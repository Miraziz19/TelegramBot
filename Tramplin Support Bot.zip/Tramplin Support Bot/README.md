Ushbu Repository telegram bot kursi uchun tayyorlandi. Darslar davomida o'tiladigan dasturlarning kodlarini aynan shu repositoryning branchlaridan topishingiz mumkin.
P.s.: Ushbu kurs Anvar Narzullayevning mukammal telegram bot kursi asosida qo'shimchalar qo'shish orqali tayyorlandi.
